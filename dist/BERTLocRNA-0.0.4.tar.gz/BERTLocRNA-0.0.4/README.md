# BERTLocRNA
Using Large language model to predict localization and other downstream task






